#!/usr/bin/env python3
import sys
import os
import math

CENTER_LAT = float(os.environ["CENTER_LAT"])
CENTER_LON = float(os.environ["CENTER_LON"])
MAX_DIST_KM = float(os.environ["MAX_DIST_KM"])

def haversine(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1 = math.radians(lat1)
    p2 = math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)

    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return r * c

first = True

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue

    if first:
        first = False
        if line.startswith("sensor_id,"):
            continue

    parts = line.split(",")
    if len(parts) != 5:
        continue

    try:
        sensor_id, lat, lon, timestamp, value = parts
        lat = float(lat)
        lon = float(lon)
        value = float(value)
    except:
        continue

    dist = haversine(CENTER_LAT, CENTER_LON, lat, lon)
    if dist <= MAX_DIST_KM:
        print("stats\t{}".format(value))
