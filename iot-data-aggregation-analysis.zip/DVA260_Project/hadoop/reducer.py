#!/usr/bin/env python3
import sys

count = 0
total = 0.0
min_val = None
max_val = None

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue

    try:
        key, value = line.split("\t")
        value = float(value)
    except:
        continue

    count += 1
    total += value

    if min_val is None or value < min_val:
        min_val = value
    if max_val is None or value > max_val:
        max_val = value

if count == 0:
    print("count\t0")
    print("min\tN/A")
    print("max\tN/A")
    print("avg\tN/A")
else:
    avg = total / count
    print("count\t{}".format(count))
    print("min\t{}".format(min_val))
    print("max\t{}".format(max_val))
    print("avg\t{}".format(avg))
