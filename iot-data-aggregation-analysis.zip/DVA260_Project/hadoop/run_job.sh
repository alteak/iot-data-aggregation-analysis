#!/bin/bash

TYPE="$1"
CENTER_LAT="$2"
CENTER_LON="$3"
MAX_DIST_KM="$4"

if [ -z "$TYPE" ] || [ -z "$CENTER_LAT" ] || [ -z "$CENTER_LON" ] || [ -z "$MAX_DIST_KM" ]; then
    echo "Usage: ./run_job.sh \"Sensor Type\" CENTER_LAT CENTER_LON MAX_DIST_KM"
    exit 1
fi

BASE_DIR="/app"
INPUT_LOCAL="/tmp/input_data.txt"
INPUT_HDFS="/tmp/iot_input"
OUTPUT_HDFS="/tmp/iot_output"

# CHANGE THIS PATH based on the result of: find / -name "hadoop-streaming*.jar" 2>/dev/null
STREAMING_JAR="/opt/hadoop-3.2.1/share/hadoop/tools/lib/hadoop-streaming-3.2.1.jar#!/bin/bash"

echo "Downloading data from Flask..."
wget -O "$INPUT_LOCAL" "http://iot_server:8080/fetch?type=$(python3 -c "import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1]))" "$TYPE")"

echo "Preparing HDFS input..."
hdfs dfs -mkdir -p "$INPUT_HDFS"
hdfs dfs -put -f "$INPUT_LOCAL" "$INPUT_HDFS/input_data.txt"
hdfs dfs -rm -r -f "$OUTPUT_HDFS"

echo "Running Hadoop Streaming job..."
hadoop jar "$STREAMING_JAR" \
  -input "$INPUT_HDFS" \
  -output "$OUTPUT_HDFS" \
  -mapper "$BASE_DIR/mapper.py" \
  -reducer "$BASE_DIR/reducer.py" \
  -file "$BASE_DIR/mapper.py" \
  -file "$BASE_DIR/reducer.py" \
  -cmdenv CENTER_LAT="$CENTER_LAT" \
  -cmdenv CENTER_LON="$CENTER_LON" \
  -cmdenv MAX_DIST_KM="$MAX_DIST_KM"

echo "Job result:"
hdfs dfs -cat "$OUTPUT_HDFS/part-00000"
