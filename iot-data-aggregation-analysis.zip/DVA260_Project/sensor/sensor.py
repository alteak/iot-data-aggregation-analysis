
import os
import time
import random
import urllib.parse
import urllib.request
from datetime import datetime, timezone

# URL e serverit Flask (DVA260_Project)
SERVER_URL = os.environ.get("SERVER_URL", "http://127.0.0.1:8080")

# ID e sensorit
SENSOR_ID = int(os.environ.get("SENSOR_ID", "1"))

# Lokacioni i sensorit
SENSOR_LAT = float(os.environ.get("SENSOR_LAT", "59.3293"))
SENSOR_LON = float(os.environ.get("SENSOR_LON", "18.0686"))

# Tipet e sensorëve që do të dërgojnë të dhëna
SENSOR_TYPES = [
    x.strip()
    for x in os.environ.get("SENSOR_TYPES", "Temperature Sensor").split(",")
]

# Sa shpesh dërgohen të dhënat (sekonda)
INTERVAL = int(os.environ.get("INTERVAL", "5"))


def generate_value(sensor_type):
    """Gjeneron një vlerë random sipas tipit të sensorit"""

    if sensor_type == "Temperature Sensor":
        return round(random.uniform(-10, 35), 2)

    if sensor_type == "Pressure Sensor":
        return round(random.uniform(980, 1040), 2)

    if sensor_type == "Air Quality Sensor":
        return round(random.uniform(0, 150), 2)

    if sensor_type == "CO2 Sensor":
        return round(random.uniform(350, 2000), 2)

    return round(random.uniform(0, 100), 2)


while True:

    for sensor_type in SENSOR_TYPES:

        # Timestamp në UTC
        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        # Gjenero një measurement
        value = generate_value(sensor_type)

        params = {
            "sensor_id": SENSOR_ID,
            "lat": SENSOR_LAT,
            "lon": SENSOR_LON,
            "type": sensor_type,
            "timestamp": timestamp,
            "value": value
        }

        # URL që thërret endpoint /store të serverit Flask
        url = SERVER_URL + "/store?" + urllib.parse.urlencode(params)

        try:
            with urllib.request.urlopen(url) as response:
                print(response.read().decode().strip(), "|", sensor_type, value)

        except Exception as e:
            print("Error sending data:", e)

    # prit INTERVAL sekonda para se të dërgosh të dhënat e radhës
    time.sleep(INTERVAL)
