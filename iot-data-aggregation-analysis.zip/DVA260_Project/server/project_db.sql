PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS sensors (
    sensor_id INTEGER PRIMARY KEY,
    latitude REAL NOT NULL CHECK(latitude >= -90 AND latitude <= 90),
    longitude REAL NOT NULL CHECK(longitude >= -180 AND longitude <= 180)
);

CREATE TABLE IF NOT EXISTS sensor_types (
    sensor_type_id INTEGER PRIMARY KEY AUTOINCREMENT,
    type_name TEXT NOT NULL UNIQUE,
    unit TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sensor_capabilities (
    sensor_id INTEGER NOT NULL,
    sensor_type_id INTEGER NOT NULL,
    PRIMARY KEY (sensor_id, sensor_type_id),
    FOREIGN KEY (sensor_id) REFERENCES sensors(sensor_id) ON DELETE CASCADE,
    FOREIGN KEY (sensor_type_id) REFERENCES sensor_types(sensor_type_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS measurements (
    measurement_id INTEGER PRIMARY KEY AUTOINCREMENT,
    sensor_id INTEGER NOT NULL,
    sensor_type_id INTEGER NOT NULL,
    timestamp_utc TEXT NOT NULL,
    value REAL NOT NULL,
    FOREIGN KEY (sensor_id, sensor_type_id)
        REFERENCES sensor_capabilities(sensor_id, sensor_type_id)
        ON DELETE CASCADE
);

INSERT OR IGNORE INTO sensor_types(type_name, unit) VALUES
('Temperature Sensor', '°C'),
('Pressure Sensor', 'hPa'),
('Air Quality Sensor', 'PM10'),
('CO2 Sensor', 'ppm');
