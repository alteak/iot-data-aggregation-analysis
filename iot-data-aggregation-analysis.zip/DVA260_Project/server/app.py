import os
import sqlite3
from collections import defaultdict
from flask import Flask, g, request, Response

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DATABASE = os.path.join(BASE_DIR, "iot.db")
INIT_SQL = os.path.join(BASE_DIR, "project_db.sql")

app = Flask(__name__)


def get_db():
    db = getattr(g, "_database", None)

    if db is None:
        db = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys = ON;")
        g._database = db

    return db


@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)

    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DATABASE)
    conn.execute("PRAGMA foreign_keys = ON;")

    with open(INIT_SQL, "r", encoding="utf-8") as f:
        conn.executescript(f.read())

    conn.commit()
    conn.close()


@app.route("/")
def home():
    return """
<h1>IoT Sensor Server</h1>

<ul>
  <li>/store?sensor_id=1&lat=59.3&lon=18.0&type=Temperature%20Sensor&timestamp=2025-02-24 12:34:00&value=13.9</li>
  <li>/retrieve?sensor_id=1&start_time=2025-02-24 00:00:00&end_time=2025-02-25 00:00:00</li>
  <li>/fetch?type=Temperature%20Sensor</li>
</ul>
"""


@app.route("/store")
def store():
    sensor_id = request.args.get("sensor_id", type=int)
    lat = request.args.get("lat", type=float)
    lon = request.args.get("lon", type=float)
    sensor_type = request.args.get("type", type=str)
    timestamp = request.args.get("timestamp", type=str)
    value = request.args.get("value", type=float)

    if sensor_id is None:
        return "missing sensor_id", 400

    if lat is None or lon is None:
        return "missing lat/lon", 400

    if not sensor_type:
        return "missing type", 400

    if not timestamp:
        return "missing timestamp", 400

    if value is None:
        return "missing value", 400

    db = get_db()

    type_row = db.execute(
        "SELECT sensor_type_id FROM sensor_types WHERE type_name = ?",
        (sensor_type,)
    ).fetchone()

    if type_row is None:
        return f"unknown sensor type: {sensor_type}", 400

    sensor_type_id = type_row["sensor_type_id"]

    db.execute("""
        INSERT INTO sensors(sensor_id, latitude, longitude)
        VALUES (?, ?, ?)
        ON CONFLICT(sensor_id) DO UPDATE SET
            latitude = excluded.latitude,
            longitude = excluded.longitude
    """, (sensor_id, lat, lon))

    db.execute("""
        INSERT OR IGNORE INTO sensor_capabilities(sensor_id, sensor_type_id)
        VALUES (?, ?)
    """, (sensor_id, sensor_type_id))

    db.execute("""
        INSERT INTO measurements(sensor_id, sensor_type_id, timestamp_utc, value)
        VALUES (?, ?, ?, ?)
    """, (sensor_id, sensor_type_id, timestamp, value))

    db.commit()

    return "stored successfully\n"


@app.route("/retrieve")
def retrieve():
    sensor_id = request.args.get("sensor_id", type=int)
    start_time = request.args.get("start_time", type=str)
    end_time = request.args.get("end_time", type=str)

    if sensor_id is None:
        return "missing sensor_id", 400

    if not start_time or not end_time:
        return "missing start_time or end_time", 400

    db = get_db()

    rows = db.execute("""
        SELECT st.type_name, st.unit, m.timestamp_utc, m.value
        FROM measurements m
        JOIN sensor_types st
        ON m.sensor_type_id = st.sensor_type_id
        WHERE m.sensor_id = ?
        AND m.timestamp_utc >= ?
        AND m.timestamp_utc <= ?
        ORDER BY st.type_name, m.timestamp_utc
    """, (sensor_id, start_time, end_time)).fetchall()

    if not rows:
        return f"<h2>No data found for sensor {sensor_id}</h2>"

    grouped = defaultdict(list)

    for row in rows:
        grouped[(row["type_name"], row["unit"])].append(row)

    html = [f"<h1>Measurements for sensor {sensor_id}</h1>"]

    for (type_name, unit), entries in grouped.items():
        html.append(f"<h2>{type_name}</h2>")
        html.append("<table border='1' cellpadding='5'>")
        html.append(f"<tr><th>Timestamp (UTC)</th><th>{unit}</th></tr>")

        for entry in entries:
            formatted_time = entry["timestamp_utc"].replace("T", " ").replace("Z", "")[:16]
            html.append(
                f"<tr><td>{formatted_time}</td><td>{entry['value']}</td></tr>"
            )

        html.append("</table><br>")

    return "\n".join(html)


@app.route("/fetch")
def fetch():
    sensor_type = request.args.get("type", type=str)

    if not sensor_type:
        return "missing type", 400

    db = get_db()

    rows = db.execute("""
        SELECT s.sensor_id, s.latitude, s.longitude, m.timestamp_utc, m.value
        FROM measurements m
        JOIN sensor_types st ON m.sensor_type_id = st.sensor_type_id
        JOIN sensors s ON m.sensor_id = s.sensor_id
        WHERE st.type_name = ?
        ORDER BY m.timestamp_utc
    """, (sensor_type,)).fetchall()

    if not rows:
        return Response(
            "sensor_id,latitude,longitude,timestamp_utc,value\n",
            mimetype="text/plain"
        )

    lines = ["sensor_id,latitude,longitude,timestamp_utc,value"]

    for row in rows:
        formatted_time = row["timestamp_utc"].replace("T", " ").replace("Z", "")[:16]
        lines.append(
            f"{row['sensor_id']},{row['latitude']},{row['longitude']},{formatted_time},{row['value']}"
        )

    return Response("\n".join(lines) + "\n", mimetype="text/plain")


@app.route("/add_sensor_type")
def add_sensor_type():
    sensor_type = request.args.get("type", type=str)
    unit = request.args.get("unit", type=str)

    if not sensor_type or not unit:
        return "missing type or unit", 400

    db = get_db()

    try:
        db.execute(
            "INSERT INTO sensor_types(type_name, unit) VALUES (?, ?)",
            (sensor_type, unit)
        )

        db.commit()

        return f"added sensor type: {sensor_type} ({unit})\n"

    except sqlite3.IntegrityError:
        return "sensor type already exists", 400


@app.route("/delete_sensor_type")
def delete_sensor_type():
    sensor_type = request.args.get("type", type=str)

    if not sensor_type:
        return "missing type", 400

    db = get_db()

    cur = db.execute(
        "DELETE FROM sensor_types WHERE type_name = ?",
        (sensor_type,)
    )

    db.commit()

    if cur.rowcount == 0:
        return "sensor type not found", 404

    return f"deleted sensor type: {sensor_type}\n"


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=8080, debug=True)
